<?php
/**
 * Antonio Miguel Alba Garcia
 */
$palabra="H-O-L-A";
$arr=explode("-", $palabra);

foreach ($arr as $value) {
  echo $value;
}


?>