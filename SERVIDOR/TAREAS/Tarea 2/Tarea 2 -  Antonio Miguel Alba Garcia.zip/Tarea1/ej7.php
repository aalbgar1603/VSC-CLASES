<?php
/**
 * Antonio Miguel Alba Garcia
 */
  // Esto establece el nivel de informes de errores para que incluya todos los tipos de errores
  error_reporting(E_ALL);

?>