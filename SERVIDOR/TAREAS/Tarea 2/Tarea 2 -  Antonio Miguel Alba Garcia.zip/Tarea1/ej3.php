<?php
/**
 * Antonio Miguel Alba Garcia
 */
  //La diferencia es que podemos dar claves opcionales a cada
  //posicion de una array y llamar los valores por esa clave
?>