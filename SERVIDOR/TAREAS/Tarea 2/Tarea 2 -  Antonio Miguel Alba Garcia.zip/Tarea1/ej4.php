<?php
/**
 * Antonio Miguel Alba Garcia
 */
  function sumar($num1, $num2) {
    return $num1+$num2;
  }
  function restar($num1, $num2) {
    return $num1-$num2;
  }
  function multiplicar($num1, $num2) {
    return $num1*$num2;
  }
  echo sumar(2,5);
  echo "\n";
  echo restar(2,5);
  echo "\n";
  echo multiplicar(2,5);
?>