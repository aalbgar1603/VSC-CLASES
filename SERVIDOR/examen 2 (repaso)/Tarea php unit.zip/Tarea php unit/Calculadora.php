<?php

//Primero instalamos composer por la terminal : composer require --dev phpunit/phpunit

class Calculadora{
    public function Sumar($a, $b){
        return $a + $b;
    }
}