<?php
//Antonio Miguel Alba Garcia

$curso = "Desarrollo Web Entorno Servidor";

echo strlen($curso)."\n";

list($var1,$var2,$var3,$var4) = explode(" ", $curso);

echo $var1."\n";
echo $var2."\n";
echo $var3."\n";
echo $var4."\n";
?>